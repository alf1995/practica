<?php

class Usuario extends CI_Model {

        protected $ci;
        public $nombre;
        public $apellido;
        public $correo;
        public $fecha_registro;

        function __construct() {
                $this->ci = & get_instance();
                $this->ci->load->database();
        }

        public function listar_usuario($count = 20)
        {
                $query = $this->db->get('usuario', $count);
                return $query->result();
        }

        public function buscar_usuario($id = '')
        {
                $query = $this->db->where('id', $id);
                $query = $this->db->get('usuario');
                return $query->result();
        }

        public function insertar_registro()
        {
                $this->nombre   = $_POST['nombre'];
                $this->apellido = $_POST['apellido'];
                $this->correo   = $_POST['correo'];
                $this->fecha_registro     = time();

                $this->ci->db->insert('usuario', $this);
        }

        public function editar_registro()
        {
                $this->nombre   = $_POST['nombre'];
                $this->apellido = $_POST['apellido'];
                $this->correo   = $_POST['correo'];
                $this->fecha_registro     = time();

                $this->ci->db->update('usuario', $this, array('id' => $_POST['id']));
        }

}