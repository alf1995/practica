<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller {

	
	public function listado()
	{
		$data['listado'] = $this->usuario->listar_usuario(10);
		$this->load->view('listado',$data);
	}

	public function agregar(){
		$this->load->view('agregar');
	}

	public function editar($id = ''){
		$data['datos_usuario'] = $this->usuario->buscar_usuario($id);
		$this->load->view('editar',$data);
	}

	public function agregar_post(){
		$this->usuario->insertar_registro();
		redirect('/crud/listado', 'location', 301);
	}

	public function editar_post(){
		$this->usuario->editar_registro();
		redirect('/crud/listado', 'location', 301);
	}
}
